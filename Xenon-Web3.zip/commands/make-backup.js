const backup = require('discord-backup');
const config = require('../config.json');

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('MANAGE_MESSAGES')){
        return message.channel.send('<a:2333verifyred:1101489269127778354> You need to have the manage messages permissions to create a backup in this server.');
    }

    backup.create(message.guild).then((backupData) => {

        return message.channel.send('<a:yes:1101488694994677812> Backup created! Here is your ID: `'+backupData.id+'\n`! Use `'+config.prefix+'load-backup '+backupData.id+'` to load the backup on another server!');

    }).catch(() => {

        return message.channel.send('<a:2333verifyred:1101489269127778354> An error occurred, please check if the bot is administrator!');

    });

};
