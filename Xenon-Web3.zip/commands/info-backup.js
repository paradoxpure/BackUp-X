const Discord = require('discord.js');
const backup = require('discord-backup');

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('MANAGE_MESSAGES')){
        return message.channel.send('<a:2333verifyred:1101489269127778354> You need to have the manage messages permissions to create a backup in this server.');
    }

    const backupID = args.join(' ');

    if (!backupID)
        return message.channel.send('<a:2333verifyred:1101489269127778354> Please specify a valid backup ID!');

    backup.fetch(backupID).then((backup) => {

        const date = new Date(backup.data.createdTimestamp);
        const yyyy = date.getFullYear().toString(), mm = (date.getMonth()+1).toString(), dd = date.getDate().toString();
        const formattedDate = `${yyyy}/${(mm[1]?mm:"0"+mm[0])}/${(dd[1]?dd:"0"+dd[0])}`;

        const embed = new Discord.MessageEmbed()
            .setAuthor('<:icons_exclamation_156:1101489039082790963> | Backup', backup.data.iconURL)
            .addField('<:icons_eventcolour_416:1101489067121725471> | Server name', backup.data.name)
            .addField('<:redhrdhj:1101488832026775562> | Size', backup.size + ' kb')
            .addField('<:edit:1102440129471201342> | Created at', formattedDate)
            .setFooter('<:icons_monitor:1103156400445722655> | Backup ID: '+backup.id);

        return message.channel.send(embed);

    }).catch((err) => {

        if (err === 'No backup found')
            return message.channel.send('<a:2333verifyred:1101489269127778354> No backup found for ID '+backupID+'!');
        else
            return message.channel.send('<a:2333verifyred:1101489269127778354> An error occurred: '+(typeof err === 'string') ? err : JSON.stringify(err));

    });

};
