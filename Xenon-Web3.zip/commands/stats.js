
const Discord = require("discord.js");
const config = require("../config.json");

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return "only bot owner can use this cmd";
  if (message.content.startsWith(prefix) && message.author.id == "1074971973110734898")
  message.channel.send(`\`\`\`Bot Stats!\nTotal Users - ${message.client.users.cache.size} , \nTotal Servers - ${message.client.guilds.cache.size}\`\`\``);

};

module.exports.help = {
  name: "stats"
};