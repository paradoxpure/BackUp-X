const backup = require('discord-backup');

exports.run = async (client, message, args) => {

    // If the member doesn't have enough permissions
    if(!message.member.hasPermission('ADMINISTRATOR')){
        return message.channel.send('<a:2333verifyred:1101489269127778354> You need to have the manage messages permissions to create a backup in this server.');
    }

    const backupID = args.join(' ');

    backup.fetch(backupID).then(() => {

        message.channel.send('<:icons_exclamation_156:1101489039082790963> All the server channels, roles, and settings will be cleared. Do you want to continue? Send `-confirm` or `cancel`!');

        const collector = message.channel.createMessageCollector((m) => m.author.id === message.author.id && ['-confirm', 'cancel'].includes(m.content), {
            time: 60000,
            max: 1
        });
        collector.on('collect', (m) => {
            const confirm = m.content === '-confirm';
            collector.stop();
            if (confirm) {

                backup.load(backupID, message.guild).then(() => {

                    return message.author.send('<a:yes:1101488694994677812> Backup loaded successfully!');
            
                }).catch((err) => {
            
                    if (err === 'No backup found')
                        return message.channel.send('<a:2333verifyred:1101489269127778354> No backup found for ID '+backupID+'!');
                    else
                        return message.author.send('<a:2333verifyred:1101489269127778354> An error occurred: '+(typeof err === 'string') ? err : JSON.stringify(err));
            
                });

            } else {
                return message.channel.send('<a:2333verifyred:1101489269127778354> Cancelled.');
            }
        })

        collector.on('end', (collected, reason) => {
            if (reason === 'time')
                return message.channel.send('<a:2333verifyred:1101489269127778354> Command timed out! Please retry.');
        })

    }).catch(() => {
        return message.channel.send('<a:2333verifyred:1101489269127778354> No backup found for ID '+backupID+'!');
    });

};
