
const Discord = require("discord.js");
const config = require("../config.json");

module.exports.run = async (client, message, args) => {
  if (message.author.bot) return;
  let prefix = config.prefix;
  if (!message.content.startsWith(prefix)) return;

  message.channel.send(`Pong ! ${client.ws.ping}`);

};

module.exports.help = {
  name: "ping"
};